# OPENSTEP-010 release and replay

Read **benchmarks/openstep-010/README.md** for the findings, and **benchmarks/openstep-010/FIESTA-RETURN.md** for the two-case external handoff. The comparison CSV, raw fields, failed attempt, uncached residual and numerical controls are in benchmarks/openstep-010/results/. The input decks in benchmarks/openstep-010/inputs/ are usable without installing Python.

Verify the original files first, then replay on a working copy. The included subset of the parent checkout preserves the paths required by its solvers. Use Python 3.12 and the supplied dependency versions. The following commands run from the extracted archive root.

```sh
sha256sum -c SHA256SUMS
python -m pip install -r benchmarks/openstep-001/requirements.txt
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
d=benchmarks/openstep-010
python "$d/inputs.py"
python "$d/recover.py" A || test "$?" -eq 2
python "$d/recover.py" B
python "$d/check_field.py"
for c in baseline-coarse baseline-fine inward-fine inward-coarse-B released-Fiesta-baseline; do
  python "$d/trace_pair.py" "$c" || exit 1
done
python "$d/compare.py" --output "$d/results/comparison.json"
python "$d/check_verdict.py"
python "$d/plot.py"
```

An exit code 2 on restart A indicates a recorded rejection. Run restart C only if both A and B are rejected. Wall-clock times, logs and compressed-file hashes can differ after a rerun. Compare the full-domain defect, constraints, hit positions, signed distances and the frozen verdict. The solver inputs, hashes and numerical decisions in this archive do not represent an independent Fiesta return.
